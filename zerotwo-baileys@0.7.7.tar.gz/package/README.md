<div align="center">

<img src="https://files.catbox.moe/e4lft4.jpg" alt="ourin-baileys banner" width="100%" />

# ourin-baileys

### Modded Baileys v7 — Interactive Messages, AI Rich Responses, Albums & More

[![npm version](https://img.shields.io/npm/v/ourin-baileys?color=CB3837&logo=npm&logoColor=white&style=for-the-badge)](https://www.npmjs.com/package/ourin-baileys)
[![npm downloads](https://img.shields.io/npm/dm/ourin-baileys?color=CB3837&logo=npm&logoColor=white&style=for-the-badge)](https://www.npmjs.com/package/ourin-baileys)
[![GitHub](https://img.shields.io/github/stars/LuckyArch/ourin-baileys?color=181717&logo=github&logoColor=white&style=for-the-badge)](https://github.com/LuckyArch/ourin-baileys)
[![License](https://img.shields.io/badge/license-MIT-blue?style=for-the-badge)](LICENSE)
[![Node](https://img.shields.io/badge/node-%3E%3D20.0.0-339933?logo=node.js&logoColor=white&style=for-the-badge)](https://nodejs.org)
[![ESM](https://img.shields.io/badge/ESM-only-F7DF1E?logo=javascript&logoColor=black&style=for-the-badge)](#)

---

**A production-ready fork of [WhiskeySockets/Baileys](https://github.com/WhiskeySockets/Baileys) v7 RC9**
with native support for interactive messages, AI rich responses (Meta AI style), album messages, and more.

Built for the **Ourin-MD** bot ecosystem.

</div>

---

## Table of Contents

- [ourin-baileys](#ourin-baileys)
  - [Modded Baileys v7 — Interactive Messages, AI Rich Responses, Albums \& More](#modded-baileys-v7--interactive-messages-ai-rich-responses-albums--more)
  - [Table of Contents](#table-of-contents)
  - [✨ Features](#-features)
  - [📦 Installation](#-installation)
    - [From NPM](#from-npm)
    - [Using Alias (Recommended for Ourin-MD Bots)](#using-alias-recommended-for-ourin-md-bots)
  - [🛠️ Quick Start](#️-quick-start)
    - [1. Project Setup](#1-project-setup)
    - [2. Install Dependencies](#2-install-dependencies)
    - [3. Create `index.js`](#3-create-indexjs)
    - [4. Run](#4-run)
  - [🏗️ Architecture](#️-architecture)
    - [Socket Layer Chain](#socket-layer-chain)
    - [Key Modules](#key-modules)
    - [Connection Flow](#connection-flow)
  - [📡 Socket API Reference](#-socket-api-reference)
    - [Connection \& Authentication](#connection--authentication)
    - [Message Sending](#message-sending)
    - [Interactive Messages](#interactive-messages)
    - [Album Messages](#album-messages)
    - [AI Rich Response Messages](#ai-rich-response-messages)
    - [Code Block V2 (Unified Response)](#code-block-v2-unified-response)
    - [Other Message Types](#other-message-types)
    - [Newsletter Methods](#newsletter-methods)
    - [Group Methods](#group-methods)
    - [Chat \& Profile Methods](#chat--profile-methods)
    - [Privacy Settings](#privacy-settings)
  - [📡 Event Reference](#-event-reference)
  - [🔧 Utility Exports](#-utility-exports)
  - [🔀 Differences from Official Baileys](#-differences-from-official-baileys)
  - [🤝 Contributing](#-contributing)
  - [📄 License](#-license)

---

## ✨ Features

| Feature                     | Description                                                      | Status |
| --------------------------- | ---------------------------------------------------------------- | ------ |
| **Interactive Messages**    | Native flow buttons, lists, menus                                | ✅     |
| **Album Messages**          | Multi-image/video album support                                  | ✅     |
| **Table V2**                | Unified response with GenATableUXPrimitive + flexible delimiters | ✅     |
| **Code Block V2**           | Unified response with 6-language syntax highlighting             | ✅     |
| **Link Message**            | Inline clickable links with citations + verification             | ✅     |
| **Payment Messages**        | Request payment with sticker/note                                | ✅     |
| **Product Messages**        | Product catalog with buttons                                     | ✅     |
| **Event Messages**          | Event creation with RSVP                                         | ✅     |
| **Poll Results**            | Poll result snapshot messages                                    | ✅     |
| **Newsletter**              | Bulk follow, resolve URL, auto-follow                            | ✅     |
| **LID Support**             | Full LID↔PN mapping, session migration                           | ✅     |
| **Identity Change Handler** | Debounced session refresh on identity change                     | ✅     |
| **Biz Node Injection**      | Automatic business node for non-BA                               | ✅     |
| **ESM Native**              | Pure ES Module output                                            | ✅     |
| **TypeScript**              | Full type definitions included                                   | ✅     |

---

## 📦 Installation

### From NPM

```bash
npm install ourin-baileys
```

### Using Alias (Recommended for Ourin-MD Bots)

Add to `package.json`:

```json
{
  "dependencies": {
    "ourin": "npm:ourin-baileys@latest"
  }
}
```

Then run:

```bash
npm install
```

> [!TIP]
> Using the alias `ourin` allows you to `import ourin from 'ourin'` without changing existing code.

---

## 🛠️ Quick Start

### 1. Project Setup

```bash
mkdir my-bot && cd my-bot
npm init -y
```

Ensure `package.json` has `"type": "module"`:

```json
{
  "name": "my-bot",
  "type": "module",
  "dependencies": {
    "ourin": "npm:ourin-baileys@latest"
  }
}
```

> [!IMPORTANT]
> **Required**: `"type": "module"` — ourin-baileys is ESM-only. Without this, imports will fail.

### 2. Install Dependencies

```bash
npm install ourin-baileys pino
```

### 3. Create `index.js`

```js
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  Browsers,
} from "ourin-baileys";
import pino from "pino";

const logger = pino({ level: "silent" });

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState("./session");

  const sock = makeWASocket({
    auth: state,
    logger,
    printQRInTerminal: true,
    browser: Browsers.ubuntu("Chrome"),
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", ({ connection, lastDisconnect }) => {
    if (connection === "close") {
      const shouldReconnect =
        lastDisconnect?.error?.output?.statusCode !==
        DisconnectReason.loggedOut;
      if (shouldReconnect) startBot();
    }
    if (connection === "open") console.log("Connected!");
  });

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg?.message || msg.key.fromMe) return;

    const text =
      msg.message.conversation || msg.message.extendedTextMessage?.text || "";

    if (text === ".ping") {
      await sock.sendMessage(msg.key.remoteJid, { text: "Pong!" });
    }
  });
}

startBot();
```

### 4. Run

```bash
node index.js
```

Scan the QR code in terminal, then send `.ping` to test.

---

## 🏗️ Architecture

### Socket Layer Chain

Each socket layer extends the previous via composition, adding functionality from bottom to top:

```
makeSocket          → WebSocket + Noise protocol + pre-key management
  makeChatsSocket   → App state sync + chat modifications + profile
    makeGroupsSocket → Group CRUD + participant management
      makeMessagesSendSocket → Message sending + rich messages + relay
        makeMessagesRecvSocket → Message receiving + decryption + notifications
          makeBusinessSocket   → Product catalog + business profile
            makeCommunitiesSocket → Community CRUD + sub-groups
              makeNewsletterSocket → Newsletter follow/unfollow/metadata
                makeWASocket      ← TOP LEVEL EXPORT
```

### Key Modules

| Module       | Path            | Description                                                      |
| ------------ | --------------- | ---------------------------------------------------------------- |
| **Socket**   | `lib/Socket/`   | Connection, messaging, groups, newsletter, business, communities |
| **Signal**   | `lib/Signal/`   | Signal protocol: 1:1 encryption, group SenderKey, LID mapping    |
| **WABinary** | `lib/WABinary/` | Binary node encoding/decoding, JID utilities                     |
| **Utils**    | `lib/Utils/`    | Crypto, auth state, noise handler, rich messages, media          |
| **WAProto**  | `WAProto/`      | Compiled protobuf encode/decode                                  |
| **WAUSync**  | `lib/WAUSync/`  | User sync protocol (contact, device, LID)                        |
| **WAM**      | `lib/WAM/`      | WhatsApp analytics binary encoding                               |
| **Types**    | `lib/Types/`    | Full TypeScript type definitions                                 |

### Connection Flow

1. WebSocket connect → Noise XX handshake (Curve25519 + AES-256-GCM)
2. QR code or Pairing Code authentication
3. `CB:success` → upload pre-keys → send passive IQ → emit `connection: 'open'`
4. Store own LID↔PN mapping, migrate own session
5. Buffer events → process offline notifications → flush → `receivedPendingNotifications: true`

---

## 📡 Socket API Reference

### Connection & Authentication

```js
const sock = makeWASocket({
  auth: state, // AuthenticationState from useMultiFileAuthState
  logger, // pino logger instance
  printQRInTerminal: true, // Print QR to terminal
  browser: Browsers.ubuntu("Chrome"), // Browser identity
  pairingCode: undefined, // Phone number for pairing code auth
  version: [2, 3000, 1035194821], // WA version
  connectTimeoutMs: 60_000, // Connection timeout
  defaultQueryTimeoutMs: 60_000, // Query timeout
  retryRequestDelayMs: 250, // Retry delay
  maxMsgRetryCount: 5, // Max message retry count
  enableRecentMessageCache: true, // Enable message retry manager
  syncFullHistory: false, // Sync full chat history
  shouldIgnoreJid: (jid) => false, // Filter specific JIDs
  newsletterAutoFollow: [], // Auto-follow newsletter JIDs on connect
});
```

**Pairing Code Authentication:**

```js
const sock = makeWASocket({
  auth: state,
  logger,
  printQRInTerminal: false,
});

sock.ev.on("connection.update", async ({ connection, qr, isNewLogin }) => {
  if (qr) {
    // QR code available (fallback)
  }
});

// Request pairing code
const code = await sock.requestPairingCode("6281234567890");
console.log("Pairing code:", code); // e.g. "A1B2-C3D4"
```

**Authentication State:**

```js
import { useMultiFileAuthState } from "ourin-baileys";

const { state, saveCreds } = await useMultiFileAuthState("./session");
// state.creds → credentials (me, platform, noise keys, etc.)
// state.keys → SignalKeyStore (pre-keys, sessions, identity keys, etc.)
// saveCreds() → persist credentials to disk
```

---

### Message Sending

```js
// Text
await sock.sendMessage(jid, { text: "Hello!" });

// Text with mention
await sock.sendMessage(jid, {
  text: "Hello @628xxx!",
  mentions: ["628xxx@s.whatsapp.net"],
});

// Image
await sock.sendMessage(jid, {
  image: { url: "./photo.jpg" },
  caption: "A photo",
});

// Video
await sock.sendMessage(jid, {
  video: { url: "./video.mp4" },
  caption: "A video",
  gifPlayback: false,
});

// Audio
await sock.sendMessage(jid, {
  audio: { url: "./audio.ogg" },
  mimetype: "audio/ogg; codecs=opus",
  ptt: true, // voice note
});

// Sticker
await sock.sendMessage(jid, {
  sticker: { url: "./sticker.webp" },
});

// Document
await sock.sendMessage(jid, {
  document: { url: "./file.pdf" },
  fileName: "document.pdf",
  mimetype: "application/pdf",
});

// Reaction
await sock.sendMessage(jid, {
  react: { key: msg.key, text: "👍" },
});

// Location
await sock.sendMessage(jid, {
  location: {
    degreesLatitude: -6.2,
    degreesLongitude: 106.8,
    name: "Jakarta",
  },
});

// Contact
await sock.sendMessage(jid, {
  contacts: {
    displayName: "Contacts",
    contacts: [
      { vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:John\nTEL:+628xxx\nEND:VCARD" },
    ],
  },
});

// Poll
await sock.sendMessage(jid, {
  poll: {
    name: "Vote!",
    values: ["Option A", "Option B", "Option C"],
    selectableCount: 1,
  },
});

// Forward message
await sock.sendMessage(jid, {
  forward: msg,
  forwardingScore: 1,
  isForwarded: true,
});

// Delete message
await sock.sendMessage(jid, { delete: msg.key });

// Edit message
await sock.sendMessage(jid, {
  text: "Edited text",
  edit: msg.key,
});
```

---

### Interactive Messages

**Native Flow Buttons:**

```js
await sock.sendMessage(jid, {
  interactiveMessage: {
    title: "Welcome!",
    footer: "Powered by Ourin",
    buttons: [
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({
          display_text: "Menu",
          id: "menu",
        }),
      },
      {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
          display_text: "Website",
          url: "https://example.com",
        }),
      },
      {
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({
          display_text: "Copy Code",
          copy_code: "OURIN2024",
        }),
      },
    ],
    header: "Choose an option",
    image: { url: "https://example.com/banner.jpg" },
  },
});
```

**List Menu (single_select):**

```js
await sock.sendMessage(jid, {
  interactiveMessage: {
    title: "Select Category",
    footer: "Powered by Ourin",
    buttons: [
      {
        name: "single_select",
        buttonParamsJson: JSON.stringify({
          title: "Menu",
          sections: [
            {
              title: "Games",
              rows: [
                { title: "Quiz", id: ".quiz" },
                { title: "Tebak Gambar", id: ".tebakgambar" },
              ],
            },
            {
              title: "Tools",
              rows: [
                { title: "Sticker", id: ".sticker" },
                { title: "TTS", id: ".tts" },
              ],
            },
          ],
        }),
      },
    ],
    header: "Bot Menu",
  },
});
```

---

### Album Messages

```js
await sock.sendMessage(jid, {
  albumMessage: [
    { image: { url: "./photo1.jpg" }, caption: "First" },
    { image: { url: "./photo2.jpg" }, caption: "Second" },
    { video: { url: "./clip.mp4" }, caption: "Video" },
  ],
});
```

> [!NOTE]
> Albums automatically set `expectedImageCount` and `expectedVideoCount` based on array content.

---

### AI Rich Response Messages

Send messages styled like Meta AI — tables, code blocks, and rich text. All rendered via `botForwardedMessage` > `richResponseMessage`.

**Table (with heading):**

```js
await sock.sendTable(
  jid,
  "Java vs JavaScript",
  ["Feature", "Java", "JavaScript"],
  [
    ["Type", "Compiled", "Interpreted"],
    ["Typing", "Static", "Dynamic"],
    ["Main Use", "Enterprise", "Web, Full-stack"],
  ],
  quoted,
  {
    headerText: "Comparison:",
    footer: "Hope this helps!",
  },
);
```

**List (without heading):**

```js
await sock.sendList(
  jid,
  "Bot Info",
  [
    ["Name", "Ourin AI"],
    ["Version", "2.4.0"],
    ["Developer", "Zann"],
  ],
  quoted,
  { footer: "© Ourin AI" },
);
```

**Code Block V1 (basic syntax highlighting):**

```js
await sock.sendCodeBlock(
  jid,
  `const greeting = "Hello World"
function sayHello(name) {
    return greeting + " " + name
}
sayHello("Ourin")`,
  quoted,
  {
    language: "javascript",
    title: "Example Code",
    footer: "Powered by Ourin",
  },
);
```

**Supported V1 languages:** `javascript`, `typescript`, `python`

**Table V2 (Unified Response):**

The V2 table uses the **unified response** format with `GenATableUXPrimitive` typename and base64-encoded data, matching the Meta AI rich response protocol.

**Features over V1:**

- String-based table input with flexible delimiters (`|` or `,` for columns, `;;` for rows)
- Unified response sections with `GenATableUXPrimitive` / `GenAIMarkdownTextUXPrimitive` typenames
- Dual output: `rows` (for submessages) + `unified_rows` (for sections)
- Enhanced `contextInfo` with `botMessageSharingInfo`

```js
await sock.sendTableV2(
  jid,
  [
    "Java vs JavaScript", // title
    "Feature | Java | JavaScript", // header (pipe-delimited)
    "Type | Compiled | Interpreted;;Typing | Static | Dynamic;;Main Use | Enterprise | Web, Full-stack", // rows (;; separated, | or , delimited)
  ],
  quoted,
  {
    headerText: "Comparison:",
    text: "Here is a comparison table:",
    footer: "Hope this helps!",
  },
);
```

**Input format:**

- `table[0]` — title string
- `table[1]` — header row (columns separated by `|` or `,`)
- `table[2+]` — data rows (rows separated by `;;`, columns by `|` or `,`)

**V2 Options:**

| Option       | Type     | Default | Description                                          |
| ------------ | -------- | ------- | ---------------------------------------------------- |
| `title`      | `string` | —       | Title (used if `headerText` not set)                 |
| `headerText` | `string` | —       | Text shown before the table                          |
| `text`       | `string` | —       | Markdown text section (GenAIMarkdownTextUXPrimitive) |
| `footer`     | `string` | —       | Text shown after the table                           |

---

### Code Block V2 (Unified Response)

The V2 code block uses the **unified response** format with `sections/view_model/primitive` structure and base64-encoded data, matching the Meta AI rich response protocol exactly.

**Features over V1:**

- 6 language families with keyword detection
- `/* */` block comment support
- `#` comment support for python/bash/lua
- Hex/binary/octal number literals
- Dual token output: numeric `codeBlock` + string-typed `unified_codeBlock`
- Unified response sections with `GenAICodeUXPrimitive` / `GenAIMarkdownTextUXPrimitive` typenames
- Enhanced `contextInfo` with `botMessageSharingInfo`

```js
await sock.sendCodeBlockV2(
  jid,
  `package main

import "fmt"

func main() {
    fmt.Println("Hello, World!")
}`,
  quoted,
  {
    language: "go",
    title: "Go Example",
    text: "Here is a Go code snippet:",
    footer: "Powered by Ourin",
  },
);
```

**Supported V2 languages:**

| Language Key | Aliases                  |
| ------------ | ------------------------ |
| `javascript` | `js`, `typescript`, `ts` |
| `python`     | `py`                     |
| `go`         | `golang`                 |
| `lua`        | —                        |
| `bash`       | `sh`, `shell`            |

**V2 Options:**

| Option     | Type     | Default        | Description                                          |
| ---------- | -------- | -------------- | ---------------------------------------------------- |
| `language` | `string` | `'javascript'` | Programming language for syntax highlighting         |
| `title`    | `string` | —              | Title text shown before the code block               |
| `text`     | `string` | —              | Markdown text section (GenAIMarkdownTextUXPrimitive) |
| `footer`   | `string` | —              | Footer text shown after the code block               |

**V2 Token Types:**

| Code | V1 Name   | V2 Name   | Description                                        |
| ---- | --------- | --------- | -------------------------------------------------- |
| 0    | `DEFAULT` | `DEFAULT` | Normal text, whitespace, operators                 |
| 1    | `KEYWORD` | `KEYWORD` | Language keywords (`const`, `func`, `if`, etc.)    |
| 2    | `METHOD`  | `METHOD`  | Function/method calls (identifier followed by `(`) |
| 3    | `STRING`  | `STR`     | String literals (`"..."`, `'...'`, `` `...` ``)    |
| 4    | `NUMBER`  | `NUMBER`  | Numeric values (int, float, hex, binary, octal)    |
| 5    | `COMMENT` | `COMMENT` | Comments (`//`, `/* */`, `#`)                      |

---

### Link Message (Inline Embeds)

Send rich text with inline clickable links using `{{IE_N}}display_text{{/IE_N}}` placeholders, with optional citation metadata and verification proofs.

```js
await sock.sendLink(
  jid,
  "Upload results:\n✅ Freeimage\n🔗 Klik: {{IE_0}}link disini{{/IE_0}}\n✅ Yardsansh\n🔗 Klik: {{IE_1}}link disini{{/IE_1}}",
  ["https://example.com/upload1", "https://example.com/upload2"],
  quoted,
  {
    headerText: "📁 Media Uploader V3",
    footer: "✨ Selesai!",
    botJid: "867051314767696@bot",
    forwardingScore: 3,
    citations: [
      {
        sourceTitle: "Freeimage",
        citationNumber: 1,
        faviconCdnUrl: "https://cdn.example.com/favicon.ico",
      },
      { sourceTitle: "Yardsansh", citationNumber: 2 },
    ],
    proofs: [
      {
        version: 1,
        useCase: 1,
        signature: "base64signature==",
        certificateChain: ["base64cert1", "base64cert2"],
      },
    ],
  },
);
```

**Link Options:**

| Option            | Type         | Default                 | Description                           |
| ----------------- | ------------ | ----------------------- | ------------------------------------- |
| `headerText`      | `string`     | —                       | Text shown before the link content    |
| `footer`          | `string`     | —                       | Text shown after the link content     |
| `botJid`          | `string`     | `'867051314767696@bot'` | Bot JID for forwardedAiBotMessageInfo |
| `forwardingScore` | `number`     | `3`                     | Forward score for context info        |
| `citations`       | `Citation[]` | `[]`                    | Citation metadata entries             |
| `proofs`          | `Proof[]`    | `[]`                    | Verification proof entries            |

**Citation object:**

| Field            | Type     | Description                                  |
| ---------------- | -------- | -------------------------------------------- |
| `sourceQuery`    | `string` | Source query text                            |
| `faviconCdnUrl`  | `string` | CDN URL for favicon                          |
| `citationNumber` | `number` | Citation index (auto-incremented if omitted) |
| `sourceTitle`    | `string` | Title of the source                          |

**Proof object:**

| Field              | Type       | Description              |
| ------------------ | ---------- | ------------------------ |
| `version`          | `number`   | Proof version            |
| `useCase`          | `number`   | Use case identifier      |
| `signature`        | `string`   | Base64 signature         |
| `certificateChain` | `string[]` | Base64 certificate chain |

---

### Other Message Types

**Payment Request:**

```js
await sock.sendMessage(jid, {
  requestPaymentMessage: {
    amount: 50000,
    currency: "IDR",
    note: "Payment for order #123",
    from: "628xxx@s.whatsapp.net",
  },
});
```

**Event:**

```js
await sock.sendMessage(jid, {
  eventMessage: {
    name: "Community Meetup",
    description: "Join us for the monthly meetup!",
    startTime: Date.now() + 86400000,
    endTime: Date.now() + 90000000,
    location: {
      name: "Jakarta",
      degreesLatitude: -6.2,
      degreesLongitude: 106.8,
    },
  },
});
```

**Poll Result:**

```js
await sock.sendMessage(jid, {
  pollResultMessage: {
    name: "Favorite Color?",
    pollVotes: [
      { optionName: "Red", optionVoteCount: 42 },
      { optionName: "Blue", optionVoteCount: 38 },
      { optionName: "Green", optionVoteCount: 25 },
    ],
  },
});
```

**Status with Mentions:**

```js
await sock.sendStatusMention({ text: "Big update coming!" }, [
  "628xxx@s.whatsapp.net",
  "groupid@g.us",
]);
```

**Product Message:**

```js
await sock.sendMessage(jid, {
  productMessage: {
    title: "Wireless Headphones",
    description: "High quality bluetooth headphones",
    productId: "WH-001",
    retailerId: "ourin-shop",
    url: "https://example.com/product",
    priceAmount1000: 299000,
    currencyCode: "IDR",
    thumbnail: { url: "https://example.com/product.jpg" },
    body: "Check out this product!",
    footer: "Ourin Shop",
    buttons: [
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({
          display_text: "Buy Now",
          id: "buy_wh001",
        }),
      },
    ],
  },
});
```

**Mixed Rich Message (custom submessages):**

```js
await sock.sendRichMessage(
  jid,
  [
    { messageType: 2, messageText: "Here is some info:" },
    {
      messageType: 4,
      tableMetadata: {
        title: "Stats",
        rows: [
          { items: ["Metric", "Value"], isHeading: true },
          { items: ["Users", "1000"] },
          { items: ["Uptime", "99.9%"] },
        ],
      },
    },
    { messageType: 2, messageText: "And some code:" },
    {
      messageType: 5,
      codeMetadata: {
        codeLanguage: "javascript",
        codeBlocks: [{ highlightType: 0, codeContent: 'console.log("OK")' }],
      },
    },
  ],
  quoted,
);
```

**SubMessage Types:**

| messageType | Name          | Payload Field          |
| ----------- | ------------- | ---------------------- |
| 0           | UNKNOWN       | —                      |
| 1           | GRID_IMAGE    | `gridImageMetadata`    |
| 2           | TEXT          | `messageText`          |
| 3           | INLINE_IMAGE  | `imageMetadata`        |
| 4           | TABLE         | `tableMetadata`        |
| 5           | CODE          | `codeMetadata`         |
| 6           | DYNAMIC       | `dynamicMetadata`      |
| 7           | MAP           | `mapMetadata`          |
| 8           | LATEX         | `latexMetadata`        |
| 9           | CONTENT_ITEMS | `contentItemsMetadata` |

---

### Newsletter Methods

```js
// Resolve channel URL to metadata
const info = await sock.cekIDSaluran("https://whatsapp.com/channel/xxxxx");
console.log(info.name, info.subscribers);

// Bulk follow multiple channels
await sock.newsletterMultipleFollow("id1@newsletter id2@newsletter");

// Fetch all subscribed channels
const channels = await sock.newsletterFetchAllSubscribe();

// Generic action (follow/unfollow/mute/unmute)
await sock.newsletterAction("id@newsletter", "follow");

// Create newsletter
const nl = await sock.newsletterCreate("My Channel", "Description");

// Update newsletter
await sock.newsletterUpdate("id@newsletter", { name: "New Name" });

// Get subscriber count
const { subscribers } = await sock.newsletterSubscribers("id@newsletter");

// Get metadata
const meta = await sock.newsletterMetadata("jid", "id@newsletter");

// Follow / Unfollow
await sock.newsletterFollow("id@newsletter");
await sock.newsletterUnfollow("id@newsletter");

// Mute / Unmute
await sock.newsletterMute("id@newsletter");
await sock.newsletterUnmute("id@newsletter");

// Update name / description / picture
await sock.newsletterUpdateName("id@newsletter", "New Name");
await sock.newsletterUpdateDescription("id@newsletter", "New Desc");
await sock.newsletterUpdatePicture("id@newsletter", mediaUpload);
await sock.newsletterRemovePicture("id@newsletter");

// React to message
await sock.newsletterReactMessage("id@newsletter", serverId, "👍");

// Fetch messages
const msgs = await sock.newsletterFetchMessages("id@newsletter", 50, 0, 0);

// Admin operations
const count = await sock.newsletterAdminCount("id@newsletter");
await sock.newsletterChangeOwner("id@newsletter", newOwnerJid);
await sock.newsletterDemote("id@newsletter", userJid);
await sock.newsletterDelete("id@newsletter");
```

---

### Group Methods

```js
// Fetch group metadata
const meta = await sock.groupMetadata("id@g.us");

// Create group
const group = await sock.groupCreate("My Group", ["628xxx@s.whatsapp.net"]);

// Leave group
await sock.groupLeave("id@g.us");

// Update subject / description
await sock.groupUpdateSubject("id@g.us", "New Subject");
await sock.groupUpdateDescription("id@g.us", "New Description");

// Participant actions: add, remove, promote, demote
const result = await sock.groupParticipantsUpdate(
  "id@g.us",
  ["628xxx@s.whatsapp.net"],
  "add", // 'remove' | 'promote' | 'demote'
);

// Handle join requests
const requests = await sock.groupRequestParticipantsList("id@g.us");
await sock.groupRequestParticipantsUpdate(
  "id@g.us",
  ["628xxx@s.whatsapp.net"],
  "approve",
);

// Invite code
const code = await sock.groupInviteCode("id@g.us");
await sock.groupRevokeInvite("id@g.us");
await sock.groupAcceptInvite("ABCDE12345");
const info = await sock.groupGetInviteInfo("ABCDE12345");

// Settings: announcement, not_announcement, locked, unlocked
await sock.groupSettingUpdate("id@g.us", "announcement");
await sock.groupSettingUpdate("id@g.us", "locked");

// Member add mode / Join approval
await sock.groupMemberAddMode("id@g.us", "admin_add");
await sock.groupJoinApprovalMode("id@g.us", "on");

// Toggle disappearing messages
await sock.groupToggleEphemeral("id@g.us", 86400); // 24h

// Fetch all participating groups
const groups = await sock.groupFetchAllParticipating();

// Update member label
await sock.updateMemberLabel("id@g.us", "VIP");
```

---

### Chat & Profile Methods

```js
// Profile picture
const url = await sock.profilePictureUrl(jid, "image");
await sock.updateProfilePicture(jid, mediaUpload);
await sock.removeProfilePicture(jid);

// Profile name / status
await sock.updateProfileName("My Name");
await sock.updateProfileStatus("Available");

// Presence
await sock.sendPresenceUpdate("available", jid);
await sock.presenceSubscribe(jid);

// Read receipts
await sock.readMessages([msg.key]);
await sock.sendReceipt(jid, participant, [msgId], "read");

// Block / Unblock
await sock.updateBlockStatus(jid, "block");
await sock.updateBlockStatus(jid, "unblock");

// Fetch blocklist
const list = await sock.fetchBlocklist();

// Chat modifications
await sock.chatModify(
  {
    archive: true,
    lastMessageOrig: msg,
    lastMessage: msg,
  },
  jid,
);

// Star messages
await sock.star(jid, [{ id: msgId, fromMe: true }], true);

// Contact management
await sock.addOrEditContact(jid, { displayName: "Name" });
await sock.removeContact(jid);

// Labels
await sock.addChatLabel(jid, labelId);
await sock.removeChatLabel(jid, labelId);
await sock.addMessageLabel(jid, messageId, labelId);

// App state sync
await sock.resyncAppState(["regular", "critical_block"], true);

// Business profile
const biz = await sock.getBusinessProfile(jid);
```

---

### Privacy Settings

```js
await sock.updateLastSeenPrivacy("all"); // 'all' | 'contacts' | 'contact_blacklist' | 'nobody'
await sock.updateOnlinePrivacy("all"); // 'all' | 'match_last_seen'
await sock.updateProfilePicturePrivacy("contacts");
await sock.updateStatusPrivacy("contacts");
await sock.updateReadReceiptsPrivacy("all"); // 'all' | 'none'
await sock.updateGroupsAddPrivacy("all"); // 'all' | 'contacts'
await sock.updateMessagesPrivacy("all"); // 'all' | 'contacts' | 'nobody'
await sock.updateCallPrivacy("everyone");
await sock.updateDefaultDisappearingMode(86400);
await sock.updateDisableLinkPreviewsPrivacy(true);
```

---

## 📡 Event Reference

```js
sock.ev.on('connection.update', ({ connection, lastDisconnect, qr, isNewLogin, receivedPendingNotifications, isOnline }) => {})
sock.ev.on('creds.update', (update) => {})
sock.ev.on('messaging-history.set', ({ chats, contacts, messages, isLatest }) => {})
sock.ev.on('chats.upsert', (chats) => {})
sock.ev.on('chats.update', (updates) => {})
sock.ev.on('chats.delete', (jids) => {})
sock.ev.on('contacts.upsert', (contacts) => {})
sock.ev.on('contacts.update', (updates) => {})
sock.ev.on('messages.upsert', ({ messages, type }) => {})
sock.ev.on('messages.update', (updates) => {})
sock.ev.on('messages.delete', (keys) => {})
sock.ev.on('messages.reaction', (reactions) => {})
sock.ev.on('message-receipt.update', (updates) => {})
sock.ev.on('groups.update', (updates) => {})
sock.ev.on('group-participants.update', (update) => {})
sock.ev.on('group.join-request', (update) => {})
sock.ev.on('call', (calls) => {})
sock.ev.on('labels.edit', (label) => {})
sock.ev.on('labels.associations', ({ associated, label, type }) => {})
sock.ev.on('newsletter.update', (updates) => {})
sock.ev.on('newsletter.follow', (jid) => {})
sock.ev.on('newsletter.unfollow', (jid) => {})
sock.ev.on('settings.update', ({ isAutoEmojiEnabled, isReadReceiptsEnabled, ... }) => {})
```

---

## 🔧 Utility Exports

```js
import {
  // Auth
  useMultiFileAuthState,
  makeCacheableSignalKeyStore,

  // Code tokenization
  tokenizeCode,
  tokenizeCodeV2,
  CodeHighlightType,
  RichSubMessageType,

  // Rich message generators
  generateTableContent,
  generateTableContentV2,
  toTableMetadataV2,
  generateListContent,
  generateCodeBlockContent,
  generateCodeBlockContentV2,
  generateLinkContent,
  generateRichMessageContent,
  generateLatexContent,
  generateLatexImageContent,
  generateLatexInlineImageContent,
  generateUnifiedResponseContent,
  captureUnifiedResponse,

  // Rich message builders
  buildRichContextInfo,
  buildBotForwardedMessage,

  // Language keyword sets
  JS_KEYWORDS,
  PYTHON_KEYWORDS,
  GO_KEYWORDS,
  LUA_KEYWORDS,
  BASH_KEYWORDS,
  LANGUAGE_KEYWORDS,

  // Crypto
  Curve,
  signedKeyPair,
  aesEncryptGCM,
  aesDecryptGCM,

  // JID utilities
  jidEncode,
  jidDecode,
  jidNormalizedUser,
  areJidsSameUser,
  isJidGroup,
  isJidNewsletter,
  isLidUser,
  isPnUser,
  isJidBot,
  isJidMetaAI,
  isJidBroadcast,
  isJidStatusBroadcast,

  // Connection
  DisconnectReason,
  Browsers,

  // Dugong (advanced message types)
  Dugong,

  // Types
  WASocket,
} from "ourin-baileys";
```

---

## 🔀 Differences from Official Baileys

| Area                 | Official Baileys v7 | ourin-baileys                            |
| -------------------- | ------------------- | ---------------------------------------- |
| Interactive messages | No native support   | Full support via Dugong                  |
| Album messages       | Not supported       | Multi-media albums                       |
| AI Rich Response     | Not available       | Table, code block, rich text             |
| Table V1             | Not available       | Basic table with headers                 |
| Table V2             | Not available       | Unified response + GenATableUXPrimitive  |
| Code Block V1        | Not available       | Syntax highlighting (JS/TS/Python)       |
| Code Block V2        | Not available       | Unified response + 6 languages           |
| Link Message         | Not available       | Inline embeds + citations + verification |
| Business nodes       | Manual injection    | Auto-inject on relay                     |
| Newsletter extras    | Basic only          | Auto-follow, bulk follow, URL resolve    |
| Button detection     | Not available       | `getButtonType()` auto-detect            |
| Payment messages     | Not supported       | Full support                             |
| Event messages       | Basic               | Enhanced all fields                      |
| Status mentions      | Not available       | `sendStatusMention()`                    |
| Product messages     | Not supported       | Catalog + buttons                        |
| LID support          | Basic               | Full LID↔PN mapping + session migration  |
| Identity changes     | No handling         | Debounced session refresh                |
| Message retry        | Basic               | `MessageRetryManager` with cache         |

---

## 🤝 Contributing

1. Fork this repo
2. Create a branch (`git checkout -b feature/name`)
3. Commit changes (`git commit -m 'feat: add feature'`)
4. Push to branch (`git push origin feature/name`)
5. Open a Pull Request

---

## 📄 License

MIT © [LuckyArch](https://github.com/LuckyArch)

> [!CAUTION]
> This library is for **educational purposes**. Ensure compliance with WhatsApp Terms of Service.

---

<div align="center">

**Made with 💚 by Zann**

[⭐ Star this repo](https://github.com/LuckyArch/ourin-baileys) · [🐛 Report Bug](https://github.com/LuckyArch/ourin-baileys/issues) · [💡 Request Feature](https://github.com/LuckyArch/ourin-baileys/issues)

</div>
